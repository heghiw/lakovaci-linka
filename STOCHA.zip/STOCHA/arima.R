
###
# CVICENI 11 - MODEL ARMA
###



# FUNKCE PRO SIMULACI ARMA(p, q) MODELU Z NORMALNIHO ROZDELENI

# n - pocet pozorovani
# alpha - konstanta
# phi - vektor AR parametru o delce p
# theta - vektor MA parametru o delce q
# sigma - smerodatna odchylka procesu E
# init.obs - vektor prvnich pozorovani

SimulateARIMA <- function(n, alpha = 0, phi = c(), theta = c(), sigma = 1, init.obs = c(),r) {
  
  p <- length(phi) # rad autoregresni posloupnosti
  q <- length(theta) # rad posloupnosti klouzavych souctu
  
  init.n <- length(init.obs) # pocet pocatecnich pozorovani
  
  e <- rnorm(n = n, mean = 0, sd = sigma) # simulace normalniho bileho sumu
  
  x <- rep(NA, n) # inicializace vektoru x
  if (init.n > 0) {
    x[1:init.n] <- init.obs
  }
  
  for (t in (init.n + 1):n) {
    x[t] <- alpha + sum(phi * x[(t - 1):(t - p)]) + sum(theta * e[(t - 1):(t - q)]) + e[t] 
    
  }
  
  if (p == 0 & q == 0) {
    message("White Noise")
  } else if (p > 0 & q == 0) {
    message("AR(", p, ") Process")
  } else if (p == 0 & q > 0) {
    message("MA(", q, ") Process")
  } else if (p > 0 & q > 0) {
    message("ARMA(", p, ",", q, ") Process")
  }
  #diffinv(x,filter=phi,method="recursive") #ZMENA AR NA ARIMA
  diffinv(x,lag = c(p,q), differences= r)
  res <- data.frame(t = 1:n, e = e, x = x) #r-ta difference

  return(res)
  
}



