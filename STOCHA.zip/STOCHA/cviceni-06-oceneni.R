
###
# CVICENI 6 - MARKOVSKE RETEZCE S OCENENIM PRECHODU
###



# VYROBNI LINKA S OCENENIM

P <- rbind(c(0.8, 0.2), c(0.4, 0.6)) # matice pravdepodobnosti prechodu
R <- rbind(c(10000, -7000), c(10000, -3000)) # matice oceneni prechodu



# FUNKCE PRO VYPOCET CELKOVYCH OCEKAVANYCH VYNOSU

# P - matice pravdepodobnosti prechodu
# R - matice oceneni prechodu
# v0 - vektor jednorazovych vynosu
# n - pocet sledovanych obdobi

MarkovChainProfit <- function(P, R, v0, n) {
  
  s <- length(v0) # pocet stavu
  
  v <- matrix(NA, nrow = n + 1, s) # matice ocekavanych vynosu s pocty sledovanych kroku v radcich a s vychozimi stavy ve sloupcich
  v[1, ] <- v0 # celkove vynosy za 0 kroku (jednorazove vynosy)
  
  q <- rowSums(P * R) # vektor primych vynosu
  
  for (m in 1:n) {
    v[m + 1, ] <- q + P %*% v[m, ] # vektor celkovych vynosu za m kroku
  }
  
  rownames(v) <- paste("doba", 0:n, sep = ".")
  colnames(v) <- paste("poc", "stav", 1:s, sep = ".")
  
  return(v)
  
}



# VYNOSY VYROBNI LINKY

v <- MarkovChainProfit(P = P, R = R, v0 = c(0, 0), n = 20)
v # celkove vynosy

df <- diff(v) # prvni diference radku
df # dodatecne vynosy

colSums(df) # sedi na posledni radek v



# VYROBNI LINKA S ALTERNATIVAMI

P.alt <- list() # inicializace seznamu matic pravdepodobnosti prechodu pro ruzne alternativy
P.alt[[1]] <- rbind(c(0.8, 0.2), c(0.8, 0.2), c(0.9, 0.1)) # pocatecni stav 1; radky - 3 alternativy, sloupce - 2 cilove stavy
P.alt[[2]] <- rbind(c(0.4, 0.6), c(0.7, 0.3)) # pocatecni stav 1; radky - 2 alternativy, sloupce - 2 cilove stavy

names(P.alt) <- paste("poc", "stav", 1:2, sep = ".")
rownames(P.alt[[1]]) <- paste("alt", 1:3, sep = ".")
colnames(P.alt[[1]]) <- paste("cil", "stav", 1:2, sep = ".")
rownames(P.alt[[2]]) <- paste("alt", 1:2, sep = ".")
colnames(P.alt[[2]]) <- paste("cil", "stav", 1:2, sep = ".")

P.alt

R.alt <- list() # icializace seznamu matic oceneni prechodu pro ruzne alternativy
R.alt[[1]] <- rbind(c(10000, -7000), c(9500, -3500), c(7500, -5500)) # pocatecni stav 1; radky - 3 alternativy, sloupce - 2 cilove stavy
R.alt[[2]] <- rbind(c(10000, -3000), c(3000, -10000)) # pocatecni stav 1; radky - 2 alternativy, sloupce - 2 cilove stavy

names(R.alt) <- paste("poc", "stav", 1:2, sep = ".")
rownames(R.alt[[1]]) <- paste("alt", 1:3, sep = ".")
colnames(R.alt[[1]]) <- paste("cil", "stav", 1:2, sep = ".")
rownames(R.alt[[2]]) <- paste("alt", 1:2, sep = ".")
colnames(R.alt[[2]]) <- paste("cil", "stav", 1:2, sep = ".")

R.alt



# FUNKCE PRO VYPOCET OPTIMALNICH CELKOVYCH VYNOSU A OPTIMALNICH ALTERNATIV

# P.alt - seznam matici pravdepodobnosti prechodu pro ruzne alternativy
# R.alt - seznam matici oceneni prechodu pro ruzne alternativy
# v0 - vektor jednorazovych vynosu
# n - pocet sledovanych obdobi

MarkovChainDecision <- function(P.alt, R.alt, v0, n) {
  
  s <- length(v0) # pocet stavu
  
  v <- matrix(NA, nrow = n + 1, s) # matice ocekavanych vynosu s pocty sledovanych kroku v radcich a s vychozimi stavy ve sloupcich
  v[1, ] <- v0 # celkove vynosy za 0 kroku (jednorazove vynosy)
  
  d <- matrix(NA, nrow = n, ncol = s) # inicializace matice optimalnich alternativ
  
  for (m in 1:n) { # projede pocty kroku od 1 do n
    
    for (i in 1:s) { # projede vsechny vychozi stavy
      
      possible.profits <- rowSums(P.alt[[i]] * R.alt[[i]]) + P.alt[[i]] %*% v[m, ] # vektor vynosu jednotlivych alternativ za dobu m pro vychozi stav i
      v[m + 1, i] <- max(possible.profits) # uloz optimalni ocekavany vynos
      d[m, i] <- which.max(possible.profits) # uloz optimalni alternativu
      
    }
    
  }
  
  rownames(v) <- paste("doba", 0:n, sep = ".")
  colnames(v) <- paste("poc", "stav", 1:s, sep = ".")
  
  rownames(d) <- paste("doba", 1:n, sep = ".")
  colnames(d) <- paste("poc", "stav", 1:s, sep = ".")
  
  res <- list(v = v, d = d)
  
  return(res)
  
}



# OPTIMALNI ROZHODOVANI PRO VYROBNI LINKU

res <- MarkovChainDecision(P.alt = P.alt, R.alt = R.alt, v0 = c(0, 0), n = 20)
res$v
res$d



# ALTERNATIVNI FORMAT DAT

data <- read.table("data-vyrobni-linka.csv", sep = ';', dec = ',', header = TRUE) # nahrani dat

states <- unique(data$poc_stav)
s <- length(states)

P.alt <- list()
R.alt <- list()

for (i in 1:s) {
  
  alternatives <- unique(data$alt[data$poc_stav == states[i]])
  a <- length(alternatives)
  
  P.alt[[i]] <- matrix(nrow = a, ncol = s)
  R.alt[[i]] <- matrix(nrow = a, ncol = s)
  
  for (k in 1:a) {
    
    for (j in 1:s) {
      
      P.alt[[i]][k, j] <- data$prst_prechodu[data$poc_stav == states[i] & data$alt == alternatives[k] & data$cil_stav == states[j]]
      R.alt[[i]][k, j] <- data$oceneni_prechodu[data$poc_stav == states[i] & data$alt == alternatives[k] & data$cil_stav == states[j]]
      
    }
    
  }
  
  rownames(P.alt[[i]]) <- alternatives
  colnames(P.alt[[i]]) <- states
  rownames(R.alt[[i]]) <- alternatives
  colnames(R.alt[[i]]) <- states
  
}

names(P.alt) <- states
names(R.alt) <- states

P.alt
R.alt


