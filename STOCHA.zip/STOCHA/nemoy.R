cas <- rep(0, 200)

for (i in 1:200) {
  cas[1] <- 0
  
  if (cas[i] < 1) {
    cas[i + 1] <- cas[i] + rexp(n = 1, rate = 100)
  }
  else if (cas[i] >= 1) {
    cas[i] = 1
    break
    
  }
}

n <- which(cas == 1)
cas <- cas[1:n]
n_hodnoty <- n - 1
hodnoty <- rep(0, n)
for (i in 1:n_hodnoty) {
  hodnoty[1] <- 0
  hodnoty[i + 1] <- hodnoty[i] + rnorm(n = 1, mean = 10, sd = 1)
}

plot(cas, hodnoty, type = "s")
