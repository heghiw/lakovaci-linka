
###
# CVICENI 8 - MARKOVSKE RETEZCE VE SPOJITEM CASE
###



# VYPOCET STACIONARNIHO ROZDELENI PRO SPOJITY CAS

# Q - matice intenzit

ContStationary <- function(Q) {
  
  s <- nrow(Q)
  
  # soustavu rovnic vyjadrime ve tvaru A %*% x = B
  # A, B jsou zadane
  # x hledame (v nasem pripade x = alpha')
  
  # rovnice alpha' %*% Q = 0, neboli Q' %*% alpha = 0
  # soustava je singularni, ma hodnost s - 1, tzn. jeden radek (treba prvni) vynecham
  A <- t(Q)
  B <- rep(0, s)
  
  # rovnice alpha' %*% 1 = 1, neboli 1' %*% alpha = 1
  # touto rovnici nahradim nejaky radek (treba prvni)
  A[1, ] <- rep(1, s)
  B[1] <- 1
  
  alpha <- solve(A, B)
  
  return(alpha)
  
}



# PRIKLAD TELEFONNI LINKY

lambda <- 3 # v prumeru zavolaji 3 lidi za hodinu / prumerna doba mezi zavolanim je 1/3 hodiny = 20 min
mu <- 4 # v prumeru je operator schopen vyridit 4 telefonaty za hodinu / prumerna doba hovoru je 1/4 hodiny = 15 min

state.names <- c("volno", "obsazeno")

Q <- rbind(c(-lambda, lambda), c(mu, -mu))
rownames(Q) <- state.names
colnames(Q) <- state.names
Q #volno/volno kumulativni P se menit t=0

alpha <- ContStationary(Q) # stacionarni rozdeleni pomoci obecne funkce
alpha

c(mu / (lambda + mu), lambda / (lambda + mu)) # rucni vypocet



# UKAZKA NAHODNEHO GENEROVANI CISEL Z EXPONENCIALNIHO A POISSONOVA ROZDELENI 

?rexp # generuje pozorovani z exponencialniho rozdeleni

rexp(n = 30, rate = 100) # vygeneruj 30 hodnot s intenzitou 100
mean(rexp(n = 1e6, rate = 100)) # prumer z 1 000 00 vygenerovanych hodnot je cca 1/100 = 0.01

rexp(n = 30, rate = lambda) # vygeneruj 30 hodnot s intenzitou lambda = 3
mean(rexp(n = 1e6, rate = lambda)) # prumer z 1 000 00 vygenerovanych hodnot je cca 1/lambda = 0.33333

x <- seq(from = 0, to = 3, length.out = 1000)
d <- dexp(x, rate = lambda)
plot(x, d, type = "l")

?rpois # generuje pozorovani z Poissonova rozdělení

rpois(n = 30, lambda = 100) # vygeneruj 30 hodnot s intenzitou 100
mean(rpois(n = 1e6, lambda = 100)) # prumer z 1 000 00 vygenerovanych hodnot je cca 100

rpois(n = 30, lambda = lambda) # vygeneruj 30 hodnot s intenzitou lambda = 3
mean(rpois(n = 1e6, lambda = lambda)) # prumer z 1 000 000 vygenerovanych hodnot je cca lambda = 3

x <- 0:20
d <- dpois(x, lambda = lambda)
plot(x, d, type = "b")



# FUNKCE PRO SIMULACI MARKOVSKY PROCES S KONECNE MNOHA STAVY VE SPOJITEM CASE

# Q - matice intenzit
# init.state - pocatecni stav
# max.time - cas po ktery je proces simulovan

ContSimulate <- function(Q, init.state = 1, max.time = 100) {
  
  s <- nrow(Q) # pocet stavu
  
  all.state <- c() # vektor vsech navstivenych stavu
  all.time <- c() # casy prechodu
  all.duration <- c() # doby setrvani 
  
  cur.state <- init.state # aktualni stav - zacnu v pocatecnim
  cur.time <- 0 # aktualni cas - zacnu v case nula
  cur.duration <- NA # aktualni doba setrvani ve stavu, zatim nevim
  
  while (cur.time < max.time) {
    
    cur.duration <- rexp(n = 1, rate = -Q[cur.state, cur.state]) # doba stravena v aktualnim case
    
    all.state <- c(all.state, cur.state)
    all.time <- c(all.time, cur.time)
    all.duration <- c(all.duration, cur.duration)
    
    cur.prob <- -Q[cur.state, ] / Q[cur.state, cur.state] # pravdepodobnosti prvniho prechodu
    cur.prob[cur.state] <- 0 # zmenim "pravdepodobnost" -1 na 0
    cur.state <- sample(x = 1:s, size = 1, prob = cur.prob) # vygeneruje novou hodnotu aktualniho stavu
    
    #cur.prob <- -Q[cur.state, -cur.state] / Q[cur.state, cur.state] # pravdepodobnosti prvniho prechodu
    #cur.state <- sample(x = (1:s)[-cur.state], size = 1, prob = cur.prob) # vygeneruje novou hodnotu aktualniho stavu
    
    cur.time <- cur.time + cur.duration # aktualizuju cas noveho prechodu
    
  }
  
  res <- data.frame(state = all.state, time = all.time, duration = all.duration)
  
  return(res)
  
}



# SIMULACE

init.state <- 1
max.time <- 1e3

res <- ContSimulate(Q, init.state, max.time)
res

plot(res$time[1:20], res$state[1:20], type = "s") #jal dlouho(x) bylo volno(y) 1 pred tim nez bylo obsazeno(y)

nrow(res) # pocet prechodu

sum(res$duration[res$state == 1]) / max.time # pomer casu straveneho ve stavu 1 (procent času)
sum(res$duration[res$state == 2]) / max.time # pomer casu straveneho ve stavu 2 (procent času)

alpha #to same
  


# FUNKCE PRO VYPOCET MATICE INTENZIT CALL CENTRA

# lambda - intenzita zavolani 
# mu - intenzita hovoru pro jednoho operatora
# o - pocet operatoru

CallCenter <- function(lambda, mu, o) {
  
  s <- o + 1 # pocet stavu
  
  Q <- matrix(0, nrow = s, ncol = s) # inicializace matice intenzit
  
  Q[1, 1] <- -lambda
  Q[1, 2] <- lambda
  
  for (i in 2:(s - 1)) {
    Q[i, i - 1] <- (i - 1) * mu
    Q[i, i + 1] <- lambda
    Q[i, i] <- -(Q[i, i - 1] + Q[i, i + 1])
  }
  
  Q[s, s - 1] <- o * mu
  Q[s, s] <- -o * mu
  
  state.names <- paste0('hovory:', 0:o)
  rownames(Q) <- state.names
  colnames(Q) <- state.names
  
  return(Q)
  
}



# PRIKLAD CALL CENTRA

Q <- CallCenter(lambda = 4, mu = 5, o = 4) #celkovy pocet stavu 5, lamda lidi v prumeru zavola za casovy okamzik, kolik lide hovor ukonci = mu
Q

alpha <- ContStationary(Q) # stacionarni rozdeleni
alpha

init.state <- 1
max.time <- 1e3

res <- ContSimulate(Q, init.state, max.time)
res

plot(res$state[1:50] - 1, type = "b")
plot(res$time[1:50], res$state[1:50] - 1, type = "s")

sum(res$duration[res$state == 1]) / max.time # pomer casu straveneho ve stavu 0
sum(res$duration[res$state == 2]) / max.time # pomer casu straveneho ve stavu 1
sum(res$duration[res$state == 3]) / max.time # pomer casu straveneho ve stavu 2
sum(res$duration[res$state == 4]) / max.time # pomer casu straveneho ve stavu 3
sum(res$duration[res$state == 5]) / max.time # pomer casu straveneho ve stavu 4
alpha


