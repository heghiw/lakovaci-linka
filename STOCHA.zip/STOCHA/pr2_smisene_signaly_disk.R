


a = rnorm(5000, 0, 1)

hist(a, breaks = 30)

qqnorm(a)
qqline(a, lwd = 2, col = "red")

shapiro.test(a)




b = round(rnorm(5000,0,1),1)

hist(b, breaks = 30)

qqnorm(b)
qqline(b, lwd = 2, col = "red")

shapiro.test(b)

table(b)
length(table(b))



c = round(rnorm(5000,0,1),3)

hist(c, breaks = 30)

qqnorm(c)
qqline(c, lwd = 2, col = "red")

shapiro.test(c)

length(table(c))







tab = table(b)

as.numeric(names(tab[tab>5]))





plot(seq(-3,3, length.out =  100), dnorm(seq(-3,3, length.out =  100), 0,1), type = "l")







sc_fce_disk = function (n,obd, chaos, plotting = TRUE) {
  
  ## rovnou si predeterminujeme argument "plotting" jako TRUE
  ## pozdeji na zaklade neho nakreslime ci nenakreslime graf
  
  score = matrix(NA, n, obd) ## vytvorime si matici
  colnames(score) = 1:obd ## pojmenujeme sloupce
  rownames(score) = 1:n ## pojmenujeme radky
  
  score[,1] = sample(seq(0,1, by =0.1), size = n, replace = TRUE)
  
  ## for cyklus dle pravidel (viz vyse)
  for (j in 2:(obd) ) {
    score[,j] = score[,j-1] + round(rnorm(n, 0, abs(score[,j-1] - 0.5)*chaos),1)
    score[,j] = ifelse( score[,j] >= 1, 1, 
                        ifelse (score[,j] <= 0, 0, score[,j]))
    
  }
  
  
  vysledky = round(score,3) ## zaokrouhlime score a nazveme jej "vysledky"
  
  ## chceme zaznamenat obecny vyvoj vysledku
  ## z tabulky score (drive) jsme mohli videt, ze nekteri testovani inklinovali k vysledku 0.5
  ## zatimco u jinych se mohla objevit zmena z "0" na "1" a vice versa
  ## prumerne hodnoty testovanych by nebyla vhodna statistika!
  ## Nevedeli bychom presne, zdali se vetsina z nich nachazi okolo "0.5" 
  ## nebo zdali fluktuuji mezi "0 az 1" 
  
  
  ## Je vyhodne zobrazit si proto smerodatnou odchylku!
  ## Vime, ze pokud by vsichni ucastnici meli vysledky na urovni "0.5", smodch by byla rovna "0".
  ## zatimco pokud by vsichni ucastnici fluktuovali vesmes rovnomerne mezi "0 az 1", 
  ## smodch by byla rovna 0.5 !  
  
  
  if (plotting == TRUE) {
    
    plot(1:obd, apply(vysledky, 2, sd), type = "l",
         ylab = "SMODCH", xlab = "obdobi",
         ylim = c(0,0.5) ) ## zobrazime si smodch pro score
    
  }
  
  
  
  return( vysledky )
  
}


## apply() ---> aplikuje libovolnou funkci na zvolenou matici
## "2" -> aplikuje funkci po sloupcich
## "1" -> aplikuje funkci po radcich




fin = sc_fce_disk(40,2000,chaos = 1.3) ## aktivujeme funkci

## lze videt, ze ve vetsine pripadu konverguje SMODCH k "0"
## Interpretace: Po "t" obdobich budou testovani mit prumerne vysledky z testu
## vysledky funkce ukladame do objektu, aby se nam nezaplnila konzole


fin = sc_fce_disk(40,2000, chaos = 1.6)

## smodch klesa, ale ne vzdy lze jednoznacne rict ---> prodlouzime pocet obdobi


fin = sc_fce_disk(40,10000, chaos = 1.6)

## smodch klesa pomaleji, ale obcas dosahuje na "0"


fin = sc_fce_disk(40,2000, chaos = 2) ## zvetsili jsme chaos

## Variabilita se drzi vesmes na konstantni urovni














###### 4) Prumerna realizace sc_fce


## K tomuto bodu se jeste vratime na druhem cviceni

## "sc_fce()" nam poskytuje pouze jedinou realizaci smerodatne odchylky ve vysledcich
## vysledky zavisi na nahode. Chceme vsak znat "obecnejsi" vysledek.
## Jaky by byl prumerny vysledek, pokud by realizaci z "sc_fce" bylo vice?


## Intuice: Pokud bychom meli tentyz experiment ale s jinymi hraci a opakovali bychom jej
## nekolikrat. Jak by se vyvijela prumerna smodch?

## Potrebujeme poznat obecne chovani modelu ---> nutnost kvuli nahode!
## tzn. jedna realizace nestaci!



sc_prum_disk = function(n,obd, chaos, opak) {
  
  smodch = matrix(NA, ncol = obd, nrow = opak) ## matice 
  
  for( ii in 1: opak) {
    sc = sc_fce_disk(n,obd,chaos, plotting = FALSE) ## POZOR: funkci sc_fce jsme si zadefinovali drive
    
    ## zastavime dilci vykreslovani vysledku (plotting = FALSE) !!!
    
    ## pouzivame drive definovanou funkci uvnitr nove funkce!
    ## ziskame pomoci ni jednu realizaci matice pro skore
    
    smodch[ii,] = apply(sc, 2, sd) ## urcime "smodch" pro jednu konkretni realizaci skore
    
    ## opakujeme nekolikrat dle poctu opakovani!
    
    
  }
  
  
  
  
  plot(1:obd, apply(smodch, 2, mean) , type = "l", lty = "twodash", lwd = 2, col = "red",
       main = paste("uroven chaosu", round(chaos,3) ),
       ylim = c(0,0.5), xlab = "obdobi", ylab = "SMODCH")
  
  ## pro zvoleny pocet opakovani nakreslime prumernou smerodatnou odchylku pro score
  
  
}


## paste() ---> umi spojit ciselny prvek s charakterovym prvkem


sc_prum_disk(20,1000,1.5,40)



## POZOR je vhodne nejprve upravit "sc_fce"
## a to tak, aby nekreslila grafy jednotlivych realizaci ---> jinak je to pomale a nenazorne

for (j in seq(1,40, length.out = 20)) {
  sc_prum_disk(20,700,j,40)
}



















### POMOCI FCE


rn_disk = function (pocet, mn, smod, krok, desetiny = TRUE) {
  
  zaok = ifelse(desetiny == TRUE, nchar(krok) - 2, -nchar(krok) + 1)
  
  
  
  
  if (smod != 0) {
    
    hranice_d = round(qnorm(0.001, mn, smod), zaok)
    
    hranice_h = round(qnorm(0.999, mn, smod), zaok)
    
    
    hodnoty = seq(hranice_d, hranice_h, by = krok)
    
    
    fx = dnorm(hodnoty, mn, smod)
    
    probab = fx/sum(fx)
    
    vystup = sample(hodnoty, size = pocet, replace = TRUE, prob = probab)
    
    
  } else if (smod == 0) {
    
    vystup = rep(mn, pocet)
    
  }
  
  
  
  return(vystup)
  
}




sc_fce_disk_rn = function (n,obd, chaos, krok = 0.1) {
  
  score = matrix(NA, n, obd) ## vytvorime si matici
  colnames(score) = 1:obd ## pojmenujeme sloupce
  rownames(score) = 1:n ## pojmenujeme radky
  
  score[,1] = sample(seq(0,1, by = krok), size = n, replace = TRUE)
  ## determinujeme vysledek prvniho testu
  ## POZOR: tentokrat musime mit vysledek diskretni!
  
  
  for (j in 2:(obd) ) {
    
    for (i in 1:n) {
      
      score[i,j] = score[i,j-1] + rn_disk(1, 0, abs(score[i,j-1] - 0.5)*chaos, krok)
      
    }
    
    score[,j] = ifelse( score[,j] >= 1, 1, 
                        ifelse (score[,j] <= 0, 0, score[,j]))
    
  }
  
  
  vysledky = round(score,3) 
  
  
  #plot(1:obd, apply(vysledky, 2, sd), type = "l",
  #    ylab = "SMODCH", xlab = "obdobi",
  #   ylim = c(0,0.5) )
  
  return( vysledky )
  
}




sc_prum_disk_rn = function(n,obd, chaos, opak) {
  
  smodch = matrix(NA, ncol = obd, nrow = opak) ## matice 
  
  for( ii in 1: opak) {
    sc = sc_fce_disk_rn(n,obd,chaos, krok = 0.2) 
    
    smodch[ii,] = apply(sc, 2, sd) 
    
    
  }
  
  
  
  
  plot(1:obd, apply(smodch, 2, mean) , type = "l", lty = "twodash", lwd = 2, col = "red",
       main = paste("uroven chaosu", round(chaos,3) ),
       ylim = c(0,0.5), xlab = "obdobi", ylab = "SMODCH")
  
  ## pro zvoleny pocet opakovani nakreslime prumernou smerodatnou odchylku pro score
  
  
}

sc_prum_disk_rn(20,700,10,20)







