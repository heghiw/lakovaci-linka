
###
# CVICENI 10 - OPTIMALIZACE V MODELU M/M/c
###



# NUMERICKY VYPOCET STACIONARNIHO ROZDELENI V PROCESU MNOZENI A ZANIKU

# up - vektor lambda_0, ..., lambda_{i-1}
# down - vektor mu_1, ..., mu_i
# return.cut - pocet vracenych pravdepodobnosti (stavy 0 az return.cut)

StationaryBirthDeath <- function(up, down, return.cut = 1e2) {
  
  alpha0 <- 1 / sum(c(1, cumprod(up / down)))
  
  alpha <- c(1, cumprod(up / down)) * alpha0
  
  return(alpha[1:(1 + return.cut)])
  
}



# NUMERICKY VYPOCET STACIONARNIHO ROZDELENI V MODELU M/M/c

# lambda - intenzita prichodu
# mu - intenzita obsluhy jedne pokladny
# c - pocet pokladen
# sum.cut - bod useknuti pri aproximaci nekonecne sumy
# return.cut - pocet vracenych pravdepodobnosti (stavy 0 az return.cut)

StationaryMMc <- function(lambda, mu, c, sum.cut = 1e5, return.cut = 1e2) {
  
  up <- rep(lambda, sum.cut)
  down <- mu * c(1:c, rep(c, sum.cut - c))
  
  alpha <- StationaryBirthDeath(up = up, down = down, return.cut = return.cut)
  
  return(alpha)
  
}



# STACIONARNI ROZDELENI V M/M/10

lambda <- 150 # intenzita prichodu
mu <- 20 # intenzita obsluhy jedne pokladny
c <- 100 # pocet pokladen

rho <- lambda / (c * mu) # intenzita provozu
rho < 1 # je system stabilni?

return.cut <- 1e2 # chci vratit stacionarni pravdepodobnosti pro stavy od 0 do 100

alpha <- StationaryMMc(lambda, mu, c, return.cut = return.cut)

sum(alpha) # uz pro prvnich 101 stavu je soucet stacionarnich pravdepodobnosti 1 (temer)

plot(0:return.cut, alpha, type = "b")



# FUNKCE PRO VYPOCET NAKLADU NA PROVOZ A GOODWILL V SYSTEMU M/M/c

# lambda - intenzita prichodu
# mu - intenzita obsluhy
# cost1 - naklady na provoz jedne pokladny za casovou jednotku
# cost2 - naklady za dlouhou frontu za casovou jednotku
# long.queue - minimalni delka dlouhe fronty
# max.c - maximalni pocet pokladen

CostMMc <- function(lambda, mu, cost1, cost2, long.queue, max.c) {
  
  cost <- data.frame(c = integer(),
                     prob.queue = numeric(),
                     cost.queue = numeric(),
                     cost.cashier = numeric(),
                     cost.total = numeric(),
                     optimal = logical())

  min.c <- floor(lambda / mu + 1) # minimalni c z podminky c > lambda / mu
  
  for (c in min.c:max.c) {
    
    # PRIKLAD
    # c = 8
    # dlouha fronta = 10
    # STAV     0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20
    # FRONTA   0  0  0  0  0  0  0  0  0  1  2  3  4  5  6  7  8  9 10 11 12
    # DLOUHA   F  F  F  F  F  F  F  F  F  F  F  F  F  F  F  F  F  F  T  T  T
    
    prob.queue <- 1 - sum(StationaryMMc(lambda = lambda, mu = mu, c = c, return.cut = c + long.queue - 1))
    cost.queue <- cost2 * prob.queue # naklady za dlouhe fronty
    cost.cashier <- cost1 * c # naklady za provoz vsech pokladen
    cost.total <- cost.queue + cost.cashier # celkove naklady
    
    cost <- rbind(cost, data.frame(c = c,
                                   prob.queue = prob.queue,
                                   cost.queue = cost.queue,
                                   cost.cashier = cost.cashier,
                                   cost.total = cost.total,
                                   optimal = FALSE))
     
  }
  
  cost$optimal[which.min(cost$cost.total)] <- TRUE # ulozi hodnotu TRUE do radku s minimalnimi naklady
  
  return(cost)
  
}



# OPTIMALNI POCET POKLADEN

lambda <- 150 # intenzita prichodu
mu <- 20 # intenzita obsluhy jedne pokladny

cost1 <- 70000 / 30 # denni naklady na provoz jedne poklady - 70 000 Kč za měsíc
cost2 <- 10000 * 24 # denni naklady za vyskyt dlouhe fronty - 10 000 Kč za hodinu
long.queue <- 10 # delka dlouhe fronty (10 a vice)
max.c <- 30

cost <- CostMMc(lambda, mu, cost1, cost2, long.queue, max.c)
cost

plot(cost$c, cost$cost.cashier, type = "b") # naklady na provoz pokladen linearne rostou
plot(cost$c, cost$cost.queue, type = "b") # naklady za dlouhou frontu klesaji podle pravdepodobnosti vyskytu
plot(cost$c, cost$cost.total, type = "b") # minimum v bode 11


