
###
# CVICENI 12 - WIENERUV PROCES
###



# SIMULACE WIENEROVA PROCESU

# mu - parametr driftu
# sigma - parametr volatility
# to - koncovy cas
# n - pocet bodu

SimulateWiener <- function(mu = 0, sigma = 1, to = 1, n = 1000) {
  
  dt <- to / n
  t <- seq(from = 0, to = to, by = dt)
  
  rn <- rnorm(n = n, mean = 0, sd = 1) # bily sum
  w <- cumsum(c(0, sqrt(dt) * rn)) # obycejny Wieneruv proces
  x <- mu * t + sigma * w # pridame drift a volatilitu
  
  res <- data.frame(time = t, value = x)
  
  return(res)
  
}

wiener <- SimulateWiener(mu = 0, sigma = 1) # Wieneruv proces
plot(wiener, type = "l")

wiener.drift <- SimulateWiener(mu = -2, sigma = 1) # Wieneruv proces s driftem a volatilitou
plot(wiener.drift, type = "l")

wiener.exp <- SimulateWiener(mu = 0, sigma = 10)
wiener.exp$value <- exp(wiener.exp$value) # exponencialni Wieneruv proces
plot(wiener.exp, type = "l")

wiener1 <- SimulateWiener(mu = 0, sigma = 1) # 2D Wieneruv proces - souradnice x
wiener2 <- SimulateWiener(mu = 0, sigma = 1) # 2D Wieneruv proces - souradnice y
plot(wiener1$value, wiener2$value, type = "l", asp = 1)



# SIMULACE ORNSTEIN-UHLENBECKOVA PROCESU

# mu - parametr dlouhodobe stredni hodnoty
# sigma - parametr volatility
# tau - parametr rychlosti navratu k dlouhodobe stredni hodnote
# to - koncovy cas
# n - pocet bodu

SimulateOrnsteinUhlenbeck <- function(mu = 0, sigma = 1, tau = 10, to = 1, n = 1000, method = "exact") {
  
  dt <- to / n
  t <- seq(from = 0, to = to, length.out = (n + 1))
  
  rn <- rnorm(n = n, mean = 0, sd = 1)
  
  if (method == "exact") {
    
    z <- rep(NA, n + 1)
    z[1] <- 0
    for (i in 2:(n + 1)) {
      z[i] <- mu + (z[i - 1] - mu) * exp(-tau * dt) + sqrt(sigma^2 / 2 / tau * (1 - exp(-2 * tau * dt))) * rn[i - 1]
    }
    
  } else if (method == "Euler-Maruyama") {
    
    z <- rep(NA, n + 1)
    z[1] <- 0
    for (i in 2:(n + 1)) {
      z[i] <- z[i - 1] + tau * (mu - z[i - 1]) * dt + sigma * sqrt(dt) * rn[i - 1]
    }
    
  }
  
  res <- data.frame(time = t, value = z)
  
  return(res)
  
}

ou <- SimulateOrnsteinUhlenbeck(mu = 2, sigma = 1, tau = 10)
plot(ou[, 1:2], type = "l")


