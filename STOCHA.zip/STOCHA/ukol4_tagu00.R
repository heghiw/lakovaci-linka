#nahrani dat a f-ce z cviceni
data <- read.table("data-petflix.csv", sep = ';', dec = ',', header = TRUE)
genres <- data[, 1] 
P <- as.matrix(data[, -1]) 
rownames(P) <- genres
colnames(P) <- genres
RegStationary <- function(P) {
  
  s <- nrow(P) # pocet stavu
  
  # soustava rovnic alpha'*P=alpha', neboli (P-I)'alpha=0
  soq.a <- t(P - diag(s)) # matice na leve strane (P-I)'
  soq.b <- rep(0, s) # vektor pravych stran 0
  
  # soustava je singularni, jeden z radku (treba posledni) nahradime rovnici 1*alpha=1
  soq.a[s, ] <- rep(1, s)
  soq.b[s] <- 1
  
  alpha <- solve(soq.a, soq.b) # stacionarni vektor je reseni soustavy rovnic
  
  return(alpha)
  
}
alpha <- RegStationary(P)
SimulateChain <- function(P, p.init, n) {
  
  s <- nrow(P) # pocet stavu
  
  x <- rep(NA, n) # inicializace pozorovani
  
  x[1] <- sample(1:s, size = 1, prob = p.init) # simulace prvniho pozorovani (nepodminene, pouzijeme vektor p.init)
  
  for (i in 2:n) {
    x[i] <- sample(1:s, size = 1, prob = P[x[i - 1], ]) # simulace dalsich pozorovani (podminene, pouzijeme matici P)
  }
  
  return(x)
  
}
EstimateTransitionMatrix <- function(x) {
  
  x <- as.factor(x) # udela typ faktor
  
  x.lev <- levels(x) # mozne stavy
  
  s <- nlevels(x) # pocet stavu
  
  P <- matrix(NA, nrow = s, ncol = s) # inicializace P
  
  x.prev <- x[-length(x)]
  x.next <- x[-1]
  
  for (i in 1:s) {
    for (j in 1:s) {
      P[i, j] <- sum(x.prev == x.lev[i] & x.next == x.lev[j]) / sum(x.prev == x.lev[i]) # odhad pravdepodobnosti prechodu
    }
  }
  
  rownames(P) <- x.lev
  colnames(P) <- x.lev
  
  return(P)
  
}
#simulace pro 1k,10k,100k
sim_1000 <- SimulateChain(P = P, p.init = alpha, n = 1000)
sim_10000 <- SimulateChain(P = P, p.init = alpha, n = 10000)
sim_100000 <- SimulateChain(P = P, p.init = alpha, n = 100000)
#odhad prechodove matice 
p_1000 <- EstimateTransitionMatrix(sim_1000)
p_10000 <- EstimateTransitionMatrix(sim_10000)
p_100000 <- EstimateTransitionMatrix(sim_100000)
#f-ce pro vypocet odmocnin souctu ctvercovych odchylek od skutecnych hodnot
odchylky <- function(matrix) {
  a <- matrix - P
  a <- a ^ 2
  a <- sqrt(sum(a))
  return(a)
  cat(a)
}

#pouziti f-ce na simulacich 
odch_1000 <- odchylky(matrix = p_1000)
odch_10000 <- odchylky(matrix = p_10000)
odch_100000 <- odchylky(matrix = p_100000)

#vysledky 
vys <-
  data.frame(
    c("simulace 1000", "simulace 10000", "simulace 100000"),
    c(odch_1000, odch_10000, odch_100000)
  )
colnames(vys) <- c("pozorovani", "odchylka")


