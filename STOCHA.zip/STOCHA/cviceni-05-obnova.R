
###
# CVICENI 5 - MODELY OBNOVY
###



# KNIHOVNY

library(expm)



# UKAZKA NOVYCH FUNKCI

rev(c(1, 2, 3)) # vrati prvky vektoru v opacnem poradi
rev(c(5, 5, 5, 8))
c(5, 5, 5, 8)[c(4, 3, 2, 1)]

cumsum(c(1, 1, 1, 1, 1)) # vrati kumulativni soucty vektoru
cumsum(c(0, 0, 0, 1, 1))
cumsum(c(1, 2, 3, 10, 1000))



# FUNKCE PRO VYPOCET STACIONARNIHO ROZDELENI

# P - prechodova matice

RegStationary <- function(P) {
  
  s <- nrow(P) # pocet stavu
  
  # soustava rovnic alpha*P=alpha, neboli (P-I)'alpha'=0
  soq.a <- t(P - diag(s)) # matice na leve strane (P-I)'
  soq.b <- rep(0, s) # vektor pravych stran 0
  
  # soustava je singularni, jeden z radku (treba prvni) nahradime rovnici alpha*1=1
  soq.a[1, ] <- rep(1, s)
  soq.b[1] <- 1
  
  alpha <- solve(soq.a, soq.b) # stacionarni vektor je reseni soustavy rovnic
  
  return(alpha)
  
}



# FUNKCE PRO VYPOCET PRECHODOVE MATICE MODELU OBNOVY

# a - (nepodmine) pravdepodobnosti selhani v jednotlivych obdobich

RenewalModel <- function(a) {
  
  s <- length(a) # pocet stavu = max pocet obdobi = zivotnost
  
  # r <- rep(NA, s) # inicializace
  # for (i in 1:s) {
  #   r[i] <- sum(a[i:s])
  # }
  
  r <- rev(cumsum(rev(a))) # pravdepodobnost, ze zarovka prezije jednotliva obdobi 0 az s-1

  # P <- matrix(0, nrow = s, ncol = s) # inicializace
  # for (i in 1:(s - 1)) {
  #   P[i, 1] <- a[i] / r[i] # zarovka selze
  #   P[i, i + 1] <- r[i + 1] / r[i] # zarovka prezije
  # }
  # P[s, 1] <- 1 # v poslednim obdobi zarovka vzdy selze
  
  P <- cbind(a / r, rbind(diag(r[-1] / r[-s]), rep(0, s - 1))) # prechodova matice
  
  return(P)
  
}



# REGULARNI MODEL OBNOVY

a <- c(0.2, 0.4, 0.3, 0.1)
a

s <- length(a)
s

P <- RenewalModel(a)
P

P %^% 2 # obsahuje nuly
P %^% 3 # obsahuje nuly
P %^% 4 # same kladne prvky => regularni retezec

alpha <- RegStationary(P) # stacionarni rozdeleni
alpha # protoze je retezec regularni, tak absolutni pravdepodbnosti jednotlivych stavu konverguji k stacionarnimu rozdeleni

r <- rev(cumsum(rev(a)))
alpha <- r / sum(r) # stacionarni rozdeleni alternativne
alpha



# FUNKCE PRO VYPOCET ABSOLUTNICH PRAVDEPODOBNOSTI

# P - prechodova matice
# pi.init - pocatecni rozdeleni
# n - pocet kroku

AbsoluteProbabilities <- function(P, pi.init, n) {
  
  s <- nrow(P) # pocet stavu
  
  pi.all <- matrix(NA, nrow = n + 1, ncol = s) # inicializace
  
  pi.all[1, ] <- pi.init # zacneme v pocatecnim rozdeleni
  
  for (i in 1:n) {
    pi.all[i + 1, ] <- pi.all[i, ] %*% P # pi(i+1) = pi(i) * P
  }
  
  colnames(pi.all) <- paste("S", 1:s, sep = "")
  rownames(pi.all) <- paste("X", 0:n, sep = "")
  
  return(pi.all)
  
}

pi.init <- c(1, 0, 0, 0)
pi.all <- AbsoluteProbabilities(P, pi.init, n = 20)
pi.all

alpha # stacionarni rozdeleni
t(t(pi.all) - alpha) # jak se absolutni pravdepodobnosti lisi od stacionarnich

pi.init <- alpha # co kdyz zacneme rovnou ve stacionarnim rozdeleni
pi.all <- AbsoluteProbabilities(P, pi.init, n = 20)
pi.all
t(t(pi.all) - alpha)

pi.init <- c(1/4, 1/4, 1/4, 1/4)
pi.all <- AbsoluteProbabilities(P, pi.init, n = 20)
pi.all

pi.all * 1000 # vekova struktura
alpha * 1000

P %^% 100
P %^% 101
P %^% 102 # konverguje k limitni matici slozenou z radku alpha

P %^% 101 - P %^% 102



# PERIODICKY MODEL OBNOVY

a <- c(0, 0.7, 0, 0.3)
a

s <- length(a)
s

P <- RenewalModel(a)
P

P %^% 2 # obsahuje 0
P %^% 3 # obsahuje 0
P %^% 4 # obsahuje 0
P %^% 10 # mocnina s^2 - 2s + 2 obsahuje 0 => neni regularni

alpha <- RegStationary(P) # stacionarni rozdeleni
alpha # stacionarni rozdeleni existuje prave jedno a ma kladne prvky

r <- rev(cumsum(rev(a)))
alpha <- r / sum(r) # stacionarni rozdeleni alternativne
alpha

pi.init <- c(1, 0, 0, 0)
pi.all <- AbsoluteProbabilities(P, pi.init, n = 20)
pi.all # absolutni pravdepodobnosti nekonverguji

pi.all[seq(from = 2, to = nrow(pi.all), by = 2), ] # liche kroky konverguji
pi.all[seq(from = 3, to = nrow(pi.all), by = 2), ] # sude kroky take konverguji

P %^% 100
P %^% 101
P %^% 102 # mocniny P nekonverguji k nejake limitni matici

(P %^% 100 + P %^% 101) / 2 # prumerovanim mozno vyresit nekonvergenci
alpha


PP <- list() # list mocnin P
for (i in 1:100) {
  PP[[i]] <- P %^% i
}

plot(sapply(PP, function(x) { x[2, 3] }), type = "b") # vyvoj dane pravdepodobnosti prechodu


