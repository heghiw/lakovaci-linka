% MODELY Z�SOB

    % I) DETERMINISTICK�
    
      % 1) EOQ
    
        % Q .........   velikost popt�vky za rok
        % N .........   celkov� n�klady za rok
        % c1 ........   jednotkov� skladovac� n�klady za rok
        % c2 ........   po�izovac� n�klady jedn� dod�vky
        % q .........   velikost jedn� dod�vky
        % Q/q .......   po�et dod�vkov�ch cykl� za rok
        % t .........   d�lka dod�vkov�ho cyklu (= 1 / po�et cykl� za rok)
        % d .........   po�izovac� lh�ta dod�vky
        % r .........   bod znovuobjedn�vky (velikost z�sob, p�i kter� je 
        %                                    nutn� vystavit objedn�vku)
            % N = c1(q/2)+c2(Q/q)   ...... q/2 = pr�m�rn� v��e z�soby
            % q*= odm[2Qc2/c1]
            % N*= odm[2Qc1c2]
            % t*= q*/Q = odm[2c2/Qc1] 
            % r*= Qd

     % 2) EOQ + neuspokojen� popt�vka
            
        % c3 ..  jednotkov� n�klady z neuspokojen� popt�vky za rok
        % s  ..  v��e neuspokojen� popt�vky na konci dod�vkov�ho 
        %        cyklu (�ekaj�c� po�adavky)
        % t1 ..  ��st dod�vkov�ho cyklu, kdy jsou po�adavky uspokojov�ny
        % t2 ..  ��st dod�vkov�ho cyklu, kdy po�adavky uspokojov�ny nejsou
        % ?  ..  pravd�podobnost uspokojen� po�adavku (pod�l ihned 
        %                                       uspokojen�ch po�adavk�)
        % ?  ..  pravd�podobnost �ek�n� (pod�l po�adavk�, je� mus� na 
        %        uspokojen� �ekat)
            % N = [c1*t1*(q-s)/2 + c2 + c3*t2*(s/2)]*Q/q 
            %   = [c1*(q-s)^2/2q + c2*(Q/q) + c3*(s^2/2q)] 
            % q*= odm[2Qc2/c1]*odm[(c1+c3)/c3]
            % s*= q* *[c1/(c1+c3)]
            % beta = s/q ; alfa=1-beta
            % beta*= s*/q* = c1/(c1+c3)
            % alfa*= 1-beta* = c3/(c1+c3)
            % N*= odm[2Qc1c2]*odm[alfa*]
            % t*= q*/Q = odm[2c2/Qc1]*odm[(c1+c3)/c3] = 
            %          = odm[2c2/Qc1]*odm[1/alfa*] 
            % r*= Qd-s*

     % 3) POQ 
     
        % P .. produk�n� kapacita za �asovou jednotku (intenzita produkce)
        % Q .. spot�eba (popt�vka) za �asovou jednotku (intenzita spot�eby)
        % c1.. n�klady na skladov�n� 1 v�robku za rok
        % c2.. fixn� n�klady jedn� v�robn� d�vky
        % t1.. doba nutn� k v�rob� 1 s�rie
        % t2.. doba pot�ebn� k vypr�zdn�n� skladu
        % d .. d�lka cyklu
            % d=t1+t2
            % N = c1*[(P-Q)/P]*(q/2)+c2*(Q/q) 
            % q*= odm[2Qc2/c1]*odm[P/(P-Q)]
            % N*= odm[2Qc1c2]*odm[(P-Q)/P]
            % r*= Qd            pro: d<=t2* 
            %   = (t*-Q)*(P-Q)  pro: jinak
            % t2*= [(P-Q)/P]*(q/Q) = [(P-Q)/P]*t*
     
  % I) STOCHASTICK�

    % 1) Spojit� popt�vka
    
        % ?Q .. st�edn� velikost popt�vky za rok
        % ?Q .. sm�rodatn� odchylka popt�vky za rok
        % ?d .. st�edn� velikost popt�vky b�hem po�izovac� lh�ty 
        %       (v�t�. ?d = ?Q � d)
        % ?d .. sm�rodatn� odchylka popt�vky b�hem po�izovac� lh�ty 
        %       (v�t�. ?d = ?Q � d )
        % w  .. pojistn� z�soba
        % ?  .. �rove� obsluhy (pravd�podobnost, �e v 1 cyklu dojde k 
        %                       neuspokojen� popt�vky)
        %       
        % r? .. bod znovuobjedn�vky, kter� zaji��uje �rove� obsluhy ?
            % q*= odm[2?Qc2/c1]
            % r*= ?d
    % P�i zadan� hodnot� ? stanov�me 
            % r?=r*+w, kde w=????,p�i�em� u? je ?-procentn� kvantil N(0,1).
            % r? ... p�i t�to hodnot� se bude objedn�vat
    % St�edn� celkov� n�klady jsou pak -->
            % N*= odm[2?Qc1c2]+c1w
 
    % 2) Optimalizace jednor�zov� vytvo�en� z�soby
    
        % Q  ........ skute�n� popt�vka
        % c1 ........ jednotkov� n�klady na p�ebyte�nou z�sobu
        % c2 ........ jednotkov� n�klady z neuspokojen� popt�vky
            % ?= c2/(c1+c2) ---> dosadit do prav�ho sloupce, podle toho, 
            %                    kam bude spadat, podle toho bude objedn�no
            
                % Q     p(Q)    P(Q<=So)
                % 1     p1      p1
                % 2     p2      p1+p2
                % 3     p3      p1+p2+p3
                % ..    ..      ..
                % n     pn      1
                %-------------------------
                % sum   1       x
            