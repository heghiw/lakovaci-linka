format long
lambda=15
mi=1/20
e=2.71828 
n=1
m=2
Pn=((lambda^n)/factorial(n))*e^-lambda
Pm=((lambda^m)/factorial(m))*e^-lambda
Pvice1=1-Pn
Pvice3=1-(Pn+Pm)
