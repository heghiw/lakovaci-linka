v(:,1)=q
for i=2:30
    v(:,i)=q+P*v(:,i-1);
    d(:,i)=v(:,i)-v(:,i-1);
end
v
d