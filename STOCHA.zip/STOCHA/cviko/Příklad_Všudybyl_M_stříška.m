n=6
I=eye(n)
P=[0 0 1/2 1/2 0 0;0 0 0 1/3 1/3 1/3;1/2 0 0 1/2 0 0; 1/4 1/4 1/4 0 1/4 0; 0 1/3 0 1/3 0 1/3;0 1/2 0 0 1/2 0]
A=P^100
Z=inv(I-P+A)
a=A(1,:)
mean (A)
diag(Z)
diag(a)
Mdiag=inv(diag(a))
Zdiag=diag(diag(Z))
E=ones(n,n)
M=(I-Z+E*Zdiag)*Mdiag