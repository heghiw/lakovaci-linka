% SIMULACE OPILCOVY NAHODNE PROCHAZKY 2
% Opilec vychazi z pozice 'start', jeho domov je na pozici 0,
% bar je na pozici 'bar'. Simuluje se 'pocet' nahodnych kroku.
%
% Oproti verzi 1 se simulace zastavi pri prvnim vyskytu absorpce.
% Jsou zde rovnez pouzity dva nove prikazy, '|', 'break', a 'fprintf'.

start = 2;
bar = 5;
pocet = 10000;

pozice = zeros(pocet+1,1);
pozice(1) = start;

for i = 1:pocet
    if (pozice(i) == 0) | pozice(i) == bar  % Operator '|' znamena 'nebo'.
        pozice = pozice(1:i);               % Zkrati se vektor pozic.
        break;                              % Prikazem 'break' opustime 'for'.
    end
    if rand(1) < 0.5 
        pozice(i+1) = pozice(i) - 1;
    else
        pozice(i+1) = pozice(i) + 1;
    end
end

fprintf('Posloupnost pozic opilce: ');  % Vypise vysledky v usporne podobe.
fprintf('%d',pozice);
fprintf('\n');                          % v�sledky na ka�dou ��dku.