% I=eye(n)                      jednotkov� matice ��du n
% ones(m,n)                     matice sam�ch jedni�ek ��du m,n
% zeros(m,n)                    matice sam�ch nul ��du m,n
% c=zeros[(m,n);1]              matice nul (m,n) a v posledn�m ��dku je 1
% a'P=a'                        jak� procento v pr�m�ru str�v�m v ....
                                %... jednotliv�ch stavech
                                
% Podm�n�n� PP p�echodu:        p(n+1)=p(n)*P'  
%                               p'(n)=p'(0)*P^n

% VEKTOR STACION�RN�CH PP       a=P^100

% P'a=a                         => (P'-I)*a=0 ; sum(ai)=1                       
% Ax=b          ---------> MATLAB: x=A\b  , kde --------->  
                                % A=[P'-eye(n);ones(1,n)]  
                                % b=[zeros(n,1);1]
                                      
% ST�EDN� DOBA P�ECHODU
            
                % M=P*(M-Mst�)-E
                % M=(I-Z+E*Zst�)*Mst�
                                % n=size(P,1)
                % Z=[(I-P+A)]^-1 , kde A=P^100 , I=eye(n)
                                % Zst�=diag(diag(Z))=Z.*eye(n)
                                % Mst�=inv(diag(a))

% KANONICK� TVAR

        % P=[Q R;0 I]
        % Q=Pkan(1:4,1:4) ..... rozm�ry podle velikosti matice!!!
        % R=Pkan(1:4,5:6) ..... rozm�ry podle velikosti matice!!!                            
        % N=inv(eye(4)-Q) ..... fundament�ln� matice pro absorp�n� M�
        %  = st�edn� po�et p�echod� mezi tranzientn�mi stavy 
        % B=N*R           ..... PP p�echodu do absorp�n�ho stavu
        % sum(N')         ..... st�edn� doba pobytu v tranzientn�ch stavech

% OCEN�N�
        % q = P.*R*ones(m,n).... okam�it� v�nos
        % vi(n)             .... st�edn� hodnota celkov�ho v�nosu
        % vi(n)=suma[pij*vj(n-1)]
         % v1=q
         % v2=q+P*v1
            % viz. skript "priklad_6"
            

