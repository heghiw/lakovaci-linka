P=[1 0 0 0 0 0;1/2 0 1/2 0 0 0;0 1/2 0 1/2 0 0;0 0 1/2 0 1/2 0;0 0 0 1/2 0 1/2;0 0 0 0 0 1]
Pkan=[0 1/2 0 0 1/2 0;1/2 0 1/2 0 0 0;0 1/2 0 1/2 0 0;0 0 1/2 0 0 1/2; 0 0 0 0 1 0;0 0 0 0 0 1]
Q=Pkan(1:4,1:4)
R=Pkan(1:4,5:6)
N=inv(eye(4)-Q) % fundament�ln� matice pro absorp�n� M�
                % nij = jsem-li v tranzientn�m stavu i, kolikr�t v pr�m�ru
                %       projdu stavem j, ne�-li se dostanu do abs. stavu 
B=N*R           % bij=PP, �e skon��m v absorp�n�m stavu j, jsem-li nyn� 
                %         v tranzientn�m stavu i
sum(N')         % st�edn� doba pobytu v tranzientn�ch stavech
                % sum (N')=N*ones(4,1) 