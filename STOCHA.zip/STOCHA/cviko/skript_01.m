n=4
A=[P'-eye(n);ones(1,n)]
b=[zeros(n,1);1]
x=A\b
