P=[.5 .5 0;1/6 1/3 1/2 ; 2/3 0 1/3]
n=3
A=[P'-eye(n);ones(1,n)]
b=[zeros(n,1);1]
x=A\b                   % pr�m�rn� setrv�n� v jednotliv�ch stavech
