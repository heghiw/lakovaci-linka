n=6                     % n=size(P,1)
P=[0 0 1/2 1/2 0 0;0 0 0 1/3 1/3 1/3;1/2 0 0 1/2 0 0;1/4 1/4 1/4 0 1/4 0;0 1/3 0 1/3 0 1/3;0 1/2 0 0 1/2 0]
E=ones(n)               % matice sam�ch jedni�ek o rozm�ru n
A=P^100         
I=eye(n)                % jednotkov� matice o rozm�ru n
Z=inv(I-P+A)            % fundament�ln� matice
a=mean(A)               % sou�et st�edn�ch hodnot sloupc�
Mstr=diag(a.^-1)        % st��ka (^) => pouze diagon�la!!
                        % Mstr=inv(diag(a))
Zstr=Z.*eye(n)          % op�t pouze diagon�ln� prvky matice Z
                        % Zstr=diag(diag(Z))
M=(I-Z+E*Zstr)*Mstr     % st�edn� doba 1.p�echodu/n�vratu