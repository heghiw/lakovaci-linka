% SIMULACE OPILCOVY NAHODNE PROCHAZKY
% Opilec vychazi z pozice 'start', jeho domov je na pozici 0,
% bar je na pozici 'bar'. Simuluje se 'pocet' nahodnych kroku.

start = 2;
bar = 5;
pocet = 29;

pozice = zeros(pocet+1,1);   % Inicialize vektoru pozic opilce.
pozice(1) = start;

for i = 1:pocet
    if pozice(i) == 0        % Je-li opilec doma, zustane doma.
        pozice(i+1) = 0;
    elseif pozice(i) == bar  % Je-li opilec v baru, zustane zustane v baru.
        pozice(i+1) = bar;
    else                     % V ostatnich pripadech se hodi minci. 
        r = rand(1);         % rand(1) vrati 1 nahodne realne cislo mezi 0 a 1.
        if r < 0.5
            pozice(i+1) = pozice(i) - 1;
        else
            pozice(i+1) = pozice(i) + 1;
        end
    end
end
fprintf('Posloupnost pozic opilce: ');  % Vypise vysledky v usporne podobe.
fprintf('%d',pozice);
fprintf('\n');                          % v�sledky na ka�dou ��dku.