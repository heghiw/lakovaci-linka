R_6_3 = [16  4; 11  2;  8  1;  4 -6;  2 -10]
P_6_3 = [.4 .6; .7 .3; .9 .1; .5 .5; .6  .4]
q=P_6_3.*R_6_3
G=q*ones(2,5)
q=G(:,1)          % vybrat MAX z 1. stavu a 2. stavu
                  % => 8,8 a -1 => d=[1;1] ...opt.alternativy pro 1.obdob�
v1=q([1 4])       % v�b�r 1. a 4. polo�ky vektoru 
