
###
# CVICENI 3 - ABSORPCNI MARKOVSKE RETEZCE
###



# FUNKCE PRO VYPOCET PRECHODOVE MATICE OPILCOVY PROCHAZKY

# s - pocet stavu
# p - pravdepodobnost, ze opilec pujde doleva

DrunkWalk <- function(s = 6, p = 0.5) {
  
  P <- matrix(0, nrow = s, ncol = s) # inicializace, same nuly
  
  P[1, 1] <- 1 # prvni radek
  P[s, s] <- 1 # posledni radek
  
  for (i in 2:(s - 1)) { # druhy az predposledni radek
    P[i, i - 1] <- p # opilec pujde doleva
    P[i, i + 1] <- 1 - p # opilec pujde doprava
  }
  
  state.names <- paste0("S", 1:s) # spoji retezce "S" a cisla od 1 do 6
  rownames(P) <- state.names # pojmenuje radky
  colnames(P) <- state.names # pojmenuje sloupce
  
  return(P)
  
}



# VYPOCET PRECHODOVE MATICE OPILCOVY PROCHAZKY

P1 <- DrunkWalk() # zavola funkci s defaultnimi hodnotami
P1

P2 <- DrunkWalk(s = 7, p = 0.4)
P2



# FUNKCE PRO SIMULACI ABSORPCNIHO RETEZEC

# P - prechodova matice
# p.init - vektor pocatecniho rozdeleni

SimulateAbs <- function(P, p.init) {
  
  s <- nrow(P) # pocet stavu
  
  is.abs <- diag(P) == 1 # jsou jednotlive stavy absorpcni?
  which.abs <- which(is.abs) # ktere stavy jsou absorpcni?
  num.abs <- sum(is.abs) # pocet absorpcnich stavu
  
  is.tr <- !is.abs # jsou jednotlive stavy tranzientni?
  which.tr <- which(is.tr) # ktere stavy jsou tranzientni?
  num.tr <- length(which.tr) # pocet tranzientich stavu
  
  x <- sample(1:s, size = 1, prob = p.init) # simulace prvniho pozorovani (nepodminene, pouzijeme vektor p.init)
  
  while (x[length(x)] %in% which.tr) { # opakuj, dokud aktualni stav nebude absorpcni
  #while (is.tr[x[length(x)]]) { # alternativne
    
    x.cur <- x[length(x)] # aktualni stav
    x.new <- sample(1:s, size = 1, prob = P[x.cur, ]) # simulace dalsich pozorovani (podminene, pouzijeme matici P)
    
    x <- c(x, x.new) # pridej x.new na konec x
    
  }
  
  return(x)
  
}



# SIMULACE ABSORPCNIHO RETEZEC

pi1 <- c(0, 0, 1, 0, 0, 0)
SimulateAbs(P1, pi1)

pi2 <- c(0, 0, 1/3, 1/3, 1/3, 0, 0)
SimulateAbs(P2, pi2)



# FUNKCE PRO ODHAD CHARAKTERISTIK ABSORPCNIHO RETEZEC POMOCI SIMULACI

# P - prechodova matice
# p.init - vektor pocatecniho rozdeleni
# n - pocet opakovani simulaci

SimulateAbsProperties <- function(P, p.init, n = 1000) {
  
  num.steps <- rep(NA, n) # inicializace, pocet kroku v jednotlivych simulacich
  end.state <- rep(NA, n) # inicializace, v jakem absorpcnim stavu se skonci v jednotlivych simulacich
  
  for (i in 1:n) {
    
    x <- SimulateAbs(P, p.init)
    
    num.steps[i] <- length(x) - 1 # pocet kroku
    end.state[i] <- x[length(x)] # posledni prvek vektoru x
    
  }
  
  hist(num.steps, breaks = 1:max(num.steps)) # vykresli histogram
  
  mean.num.steps <- mean(num.steps) # prumerny pocet kroku
  prob.end.state <- table(end.state) / n # pravdepodobnosti jednotlivych konecnych stavu
  
  res <- list(mean.num.steps = mean.num.steps, prob.end.state = prob.end.state) # slepi dve promenne do seznamu
  
  return(res)
  
}



# ODHAD CHARAKTERISTIK ABSORPCNIHO RETEZEC POMOCI SIMULACI

SimulateAbsProperties(P1, pi1, n = 10000)

SimulateAbsProperties(P2, pi2, n = 10000)



# FUNKCE PRO VYPOCET FUNDAMENTALNI MATICE ABSORPCNIHO RETEZCE

# P - prechodova matice

AbsFundamental <- function(P) {
  
  s <- nrow(P) # pocet stavu
  
  is.abs <- diag(P) == 1 # jsou jednotlive stavy absorpcni?
  which.abs <- which(is.abs) # ktere stavy jsou absorpcni?
  num.abs <- sum(is.abs) # pocet absorpcnich stavu
  
  is.tr <- !is.abs # jsou jednotlive stavy tranzientni?
  which.tr <- which(is.tr) # ktere stavy jsou tranzientni?
  num.tr <- length(which.tr) # pocet tranzientich stavu
  
  Q <- P[is.tr, is.tr] # pravdepodobnosti prechodu z tranzientnich stavu do tranzientnich
  #Q <- P[which.tr, which.tr] # alternativne
  
  N <- solve(diag(num.tr) - Q) # fundamentalni matice, solve() vrati inverzi matice
  
  return(N)
  
}



# VYPOCET FUNDAMENTALNI MATICE ABSORPCNIHO RETEZCE

N1 <- AbsFundamental(P1)
N1
rowSums(N1)

N2 <- AbsFundamental(P2)
N2
rowSums(N2)



# FUNKCE PRO VYPOCET PRAVDEPODOBNOSTI ABSORPCE

# P - prechodova matice

AbsProb <- function(P) {

  N <- AbsFundamental(P) # fundamentalni matice
  
  R <- P[diag(P) < 1, diag(P) == 1]
  
  B <- N %*% R
  
  return(B)
  
}



# VYPOCET PRAVDEPODOBNOSTI ABSORPCE

B1 <- AbsProb(P1)
B1

B2 <- AbsProb(P2)
B2


