

CallCenter <-
  function(lambda = 4,
           mu = 5,
           o = 4,
           alpha = 3,
           w = 5) {
    s <- o + w + 1  # pocet stavu
    
    Q <- matrix(0, nrow = s, ncol = s) # inicializace matice intenzit
    
    Q[1, 1] <- -lambda
    Q[1, 2] <- lambda
    
    for (i in 2:o) {
      Q[i, i - 1] <- (i - 1) * mu
      Q[i, i + 1] <- lambda
     
    }
    
    for (i in (o + 1):(s - 1)) {
      Q[i, i + 1] <- lambda
      Q[i + 1, i] <- (i - o) * alpha
    }
    Q[(o + 1):s, o] <- o * mu
    
for (i in 2:s){
  Q[i,i]<- -sum(Q[i,])
}
    

    rownames(Q) <-c(0:o,rep("fronta",w))
    colnames(Q) <-c(0:o,rep("fronta",w))
    return(Q)
    
  }


L<-CallCenter(lambda = 4, mu = 5, o = 7, alpha = 3, w = 3)

print(L)
