
###
# CVICENI 2 - KLASIFIKACE STAVU
###



# KNIHOVNA PRO MOCNENI MATIC

library(expm)



# FUNKCE PRO OVERENI STOCHASTICKE MATICE

# P - prechodova matice

IsMatrixStochastic <- function(P) {
  sto <- (all(P >= 0) && all(abs(rowSums(P) - 1) < 1e-9))
  return(sto)
}



# FUNKCE PRO VYPOCET MATICE DOSAZITELNOSTI

# P - prechodova matice

ReachabilityMatrix <- function(P) {
  s <- nrow(P) # pocet stavu
  reach <- matrix(FALSE, nrow = s, ncol = s) # inicializace matice
  for (t in 0:s) { # dosazitelnost staci overit pro pocet kroku 0 az s
    reach <- reach | (P %^% t > 0) # bud dosazitelnost za t-1 kroku nebo za t kroku
  }
  return(reach)
}



# FUNKCE PRO URCENI ROZLOZITELNOSTI RETEZCE

# P - prechodova matice

IsIrredeucible <- function(P) {
  reach <- ReachabilityMatrix(P)
  irr <- all(reach)
  return(irr)
}



# FUNKCE PRO URCENI KOMUNIKACNICH TRID (NEMUSI BYT UZAVRENE)

# P - prechodova matice

CommunicationClasses <- function(P) {
  s <- nrow(P) # pocet stavu
  reach <- ReachabilityMatrix(P) # matice dosazitelnosti
  com <- reach & t(reach) # matice komunikace
  cl <- rep(NA, times = s) # inicializace vektoru trid
  i <- 0 # inicializace cisla tridy
  while (any(is.na(cl))) { # opakuj, doku jeste existuje prvek bez prirazene tridy
    i <- i + 1 # zvys cislo tridy o jedna
    j <- which(is.na(cl))[1] # vyber jeden stav, ktery jeste nema prirazenou tridu
    cl[com[j, ]] <- paste0("class", i) # prirad tridu i vsem stavum, se kterymi j komunikuje (vcetne sama sebe)
  }
  cl <- as.factor(cl)
  names(cl) <- rownames(P)
  return(cl)
}



# FUNKCE PRO VYPOCET PERIOD STAVU

# P - prechodova matice

Periodicity <- function(P) {
  s <- nrow(P) # pocet stavu
  n <- s^2 # zkusime mocniny az do nejakeho velkeho cisla, snad bude stacit s^2
  per <- rep(1, times = s) # incializace vektoru period
  ret <- matrix(NA, nrow = n, ncol = s) # inicializace matice navratu
  for (t in 1:n) {
    ret[t, ] <- diag(P %^% t) > 0 # je mozne se vratit presne po t krocich?
  }
  for (i in 1:s) { # projede vsechny stavy
    for (j in 1:s) { # projede vsechny mozne periody
      if (all(which(ret[, i]) %% j == 0)) { # jsou vsechny delky navratu delitelne j?
        per[i] <- j
      }
    }
  }
  names(per) <- rownames(P)
  return(per)
}



# PRIKLAD

## Stavy:
## I1, I2, I3, A1, A2, A3, M1, M2, M3, M4, B
## Interpretace: Jednotlive cinnosti, ktere mohu delat ve firme a kam povedou

## I... Internship (po nekolika zkusebnich cinnostech se dostanu bud do "A" nebo do "M")
## A... Administrace (temer nemozne zmenit pracovni pozici)
## M... Management (Prubezne prace na projektech)
## B... Boss (Ridim firmu a predpoklad, ze pro zkoumanou dobu necelim konkurenci)

## I1 ---> zakladni cinnost bez moznosti povyseni (kopirka)
## I2 ---> perspektivni cinnost, ktera muze vest na povyseni do administrativy (office)
## I3 ---> perspektivni cinnost, ktera muze vest na povyseni do managementu (projekt)

## A1 ---> Administrativni, periodicka cinnost (organizace zajezdu)
## A2 ---> Administrativni, periodicka cinnost (inventura)
## A3 ---> Administrativni, periodicka cinnost (velky firemni vecirek)

## M1 ---> Vetsi prace na bezicim projektu (jiz zavedenem)
## M2 ---> Dokoncovani projektu (zde se rozhoduje o mem prinosu pro firmu)
## M3 ---> Nalezeni noveho zakaznika (vlastni projekt)
## M4 ---> Ticho pred bouri (pred novym projektem)

## B ---> Stanu se bossem (a jim take zustanu)

P <- matrix(NA, 11, 11)

stavy <- c("I1", "I2", "I3", "A1", "A2", "A3", "M1", "M2", "M3", "M4", "B")
colnames(P) <- stavy
rownames(P) <- stavy

P[1, ] = c(0.8, 0.17, 0.03, rep(0, 8))
P[2, ] = c(0.09, 0.65, 0.12, 0.14, rep(0, 7) )
P[3, ] = c(0.07, 0.48, 0.38, rep(0, 3), 0.07, rep(0, 4))
P[4, ] = c(rep(0, 4), 1, rep(0, 6))
P[5, ] = c(rep(0, 5), 1, rep(0, 5))
P[6, ] = c(rep(0, 3), 1, rep(0, 7))
P[7, ] = c(rep(0, 7), 1, rep(0, 3))
P[8, ] = c(rep(0, 9), 0.96, 0.04)
P[9, ] = c(rep(0, 7), 1, rep(0, 3))
P[10,] = c(rep(0, 6), 0.75, 0, 0.25, 0,0)
P[11,] = c(rep(0, 10), 1)

P

IsMatrixStochastic(P)
ReachabilityMatrix(P)
IsIrredeucible(P)
CommunicationClasses(P)
Periodicity(P)


