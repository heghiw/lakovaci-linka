
###
# CVICENI 7 - NAHODNA PROCHAZKA
###



# FUNKCE PRO SIMULACI NAHODNE PROCHAZKY

# n - pocet kroku
# p - pravdepodobnost kroku doprava (+1)
# start - pocatecni hodnota procesu

SimulateRandomWalk <- function(n, p = 1/2, start = 0) {

  steps <- sample(c(1, -1), size = n, replace = TRUE, prob = c(p, 1 - p))
  
  y <- cumsum(c(start, steps))
  
  data <- data.frame(t = 0:n, y = y)
  
  return(data)
  
}



# SIMULACE A VYKRESLENI OBRAZKU

n <- 1000
p <- 0.20
start <- 0

data.walk <- SimulateRandomWalk(n = n, p = p, start = start)

#plot(data.walk$t, data.walk$y, type = "b")
plot(data.walk, type = "b")
lines(c(0, n), c(0, 0))



# FUNKCE PRO SIMULACI NAHODNE PROCHAZKY S BARIERAMI

# n - pocet kroku
# p - pravdepodobnost kroku doprava (+1)
# start - pocatecni hodnota procesu
# bar1 - prvni bariera
# bar2 - druha bariera
# on.hit - "mirror" pokud se proces odrazi od bariery nebo zustane, "bounce" pokud se vzdy odrazi, "absorb" pokud vzdy zustane, "reset" vrati retezec na start

SimulateRandomWalkBarrier <- function(n, p = 1/2, start = 0, bar1 = -Inf, bar2 = Inf, on.hit = "mirror") {

  bar.bot <- min(bar1, bar2)
  bar.top <- max(bar1, bar2)
  
  ok.start <- (start >= bar.bot) & (start <= bar.top)
  
  if (!ok.start) {
    stop("Pocatecni hodnota procesu lezi mimo bariery!")
  }
  
  y <- rep(NA, n + 1)
  y[1] <- start
  
  for (i in 1:n) {
    
    if (y[i] == bar.top) {
      
      if (on.hit == "mirror") {
        y[i + 1] <- y[i] + sample(c(0, -1), size = 1, prob = c(p, 1 - p))  
      } else if (on.hit == "bounce") {
        y[i + 1] <- y[i] - 1
      } else if (on.hit == "absorb") {
        y[i + 1] <- y[i]
      } else if (on.hit == "reset") {
        y[i + 1] <- start
      }

    } else if (y[i] == bar.bot) {
      
      if (on.hit == "mirror") {
        y[i + 1] <- y[i] + sample(c(1, 0), size = 1, prob = c(p, 1 - p))  
      } else if (on.hit == "bounce") {
        y[i + 1] <- y[i] + 1
      } else if (on.hit == "absorb") {
        y[i + 1] <- y[i]
      } else if (on.hit == "reset") {
        y[i + 1] <- start
      }
      
    } else {
      
      y[i + 1] <- y[i] + sample(c(1, -1), size = 1, prob = c(p, 1 - p))
      
    }
    
  }
  
  data <- data.frame(t = 0:n, y = y)
  
  return(data)
  
}



# SIMULACE A VYKRESLENI OBRAZKU

n <- 1000
p <- 1/2
start <- 0
bar1 <- 0
bar2 <- Inf
on.hit <- "mirror"

data.walk <- SimulateRandomWalkBarrier(n = n, p = p, start = start, bar1 = bar1, bar2 = bar2, on.hit = on.hit)

plot(data.walk$t, data.walk$y, type = "b")
lines(c(0, n), c(0, 0))



# MOMENTY A HISTOGRAM NAHODNE PROCHAZKY S BARIERAMI

n <- 100
p <- 0.3
start <- 0
bar1 = 0
bar2 = Inf
on.hit <- "mirror"

sim.rep <- 1e4
y.all.end <- rep(NA, sim.rep)
  
for (i in 1: sim.rep) {
    
    result <- SimulateRandomWalkBarrier(n = n, p = p, start = start, bar1 = bar1, bar2 = bar2, on.hit = on.hit)
    y.all.end[i] <- result$y[n]
    
}

mean(y.all.end)
var(y.all.end)

hist(y.all.end)
table(y.all.end) / sim.rep



# STACIONARNI CHARAKTERISTIKY

n <- 1e5

rho <- p / (1 - p)

stat.dist <- (1 - rho) * rho^(0:n) # stacionarni rozdeleni
stat.dist[1:30]

ex <- sum((0:n)*stat.dist) # stredni hodnota
ex

varx <- sum((0:n - ex)^2*stat.dist) # rozptyl
varx



# SROVNANI RYCHLOSTI

fun1.start <- Sys.time()
fun1.result <- SimulateRandomWalk(n = 1e6)
fun1.end <- Sys.time()
fun1.duration <- fun1.end - fun1.start
fun1.duration

fun2.start <- Sys.time()
fun2.result <- SimulateRandomWalkBarrier(n = 1e6)
fun2.end <- Sys.time()
fun2.duration <- fun2.end - fun2.start
fun2.duration


