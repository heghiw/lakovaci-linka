library(expm)

a <- c(0, 0.7, 0, 0.3)
RenewalModel <- function(a) {
  
  s <- length(a) # pocet stavu = max pocet obdobi = zivotnost
  
  # r <- rep(NA, s) # inicializace
  # for (i in 1:s) {
  #   r[i] <- sum(a[i:s])
  # }
  
  r <- rev(cumsum(rev(a))) # pravdepodobnost, ze zarovka prezije jednotliva obdobi 0 az s-1
  
  # P <- matrix(0, nrow = s, ncol = s) # inicializace
  # for (i in 1:(s - 1)) {
  #   P[i, 1] <- a[i] / r[i] # zarovka selze
  #   P[i, i + 1] <- r[i + 1] / r[i] # zarovka prezije
  # }
  # P[s, 1] <- 1 # v poslednim obdobi zarovka vzdy selze
  
  P <- cbind(a / r, rbind(diag(r[-1] / r[-s]), rep(0, s - 1))) # prechodova matice
  
  return(P)
  
}
P <- RenewalModel(a)

RegStationary <- function(P) {
  
  s <- nrow(P) # pocet stavu
  
  # soustava rovnic alpha*P=alpha, neboli (P-I)'alpha'=0
  soq.a <- t(P - diag(s)) # matice na leve strane (P-I)'
  soq.b <- rep(0, s) # vektor pravych stran 0
  
  # soustava je singularni, jeden z radku (treba prvni) nahradime rovnici alpha*1=1
  soq.a[1, ] <- rep(1, s)
  soq.b[1] <- 1
  
  alpha <- solve(soq.a, soq.b) # stacionarni vektor je reseni soustavy rovnic
  
  return(alpha)
  
}




#ukol_5 f-ce pro vypocet matice A u nerozlozitelnych retezcu

A_fun<-function(P=P,t){ #funkce pro zavedeni limitni matice na t kroku 
  PP<-list()
for (i in 1:t) {
  PP[[i]] <- P %^%(i)
  
}
  I<-diag(x=1,nrow=nrow(P),ncol=ncol(P)) #zavedeme jednotkovou matici I
  A<-(I + Reduce("+", PP))/(t+1)
  return(A)
}





is_konv<-function(P){ # porovnani limitni matice s vektorem alpha
  t=100 #1,10,....
  alpha=RegStationary(P)
  repeat{
  A<-A_fun(P=P,t=t)
  if (setequal(round((A[1,]),3),           #po zvetseni argumentu digits zvetsi se presnost 
               round(alpha,3))) {
    return(T)}
  else {t=t+1}
  
  }
  
}
is_konv(P) #  TRUE matice konverguje pri nekterem t, jestli zmenime argument funkce return () 
          #v is_konv na t (pocet kroku) a zaokrohlime na 5 cisel dostaneme presnejsi znaceni t 
          #ktere muzeme pouzit v f-ce A_fun 

