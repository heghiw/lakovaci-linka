```r
# Nastavení náhodného semene pro reprodukovatelnost výsledků
set.seed(2501)

# Definice funkce pro simulaci náhodné procházky s bariérami
SimulateRandomWalkBarrier2 <-
  function(n,
           p = 0.4,
           p1 = 0.4,
           p2 = 0.2,
           start = 0,
           bar1 = -Inf,
           bar2 = Inf) {
    
    # Určení dolní a horní bariéry
    bar.bot <- min(bar1, bar2)
    bar.top <- max(bar1, bar2)
    
    # Kontrola, zda počáteční hodnota leží mezi bariérami
    ok.start <- (start >= bar.bot) & (start <= bar.top)
    
    if (!ok.start) {
      stop("Počáteční hodnota procesu leží mimo bariéry!")
    }
    
    # Inicializace vektoru pro uložení hodnot náhodné procházky
    y <- rep(NA, n + 1)
    y[1] <- start
    
    # Počet kroků včetně počáteční hodnoty
    a <- n + 1
    
    # Smyčka pro simulaci náhodné procházky
    for (i in 1:a) {
      
      # Kontrola, zda hodnota překročila horní bariéru
      if (y[i] >= bar.top) {
        y[i] <- y[i] - abs(y[i] - y[i-1]) # Korekce hodnoty na bariéře
        y[i + 1] <- y[i] + sample(c(1, -1, -5), size = 1, prob = c(p, p1, p2)) # Generování dalšího kroku
      }
      
      # Kontrola, zda hodnota překročila dolní bariéru
      else if (y[i] <= bar.bot) {
        y[i] <- 1 + abs(y[i-1] - abs(y[i] - y[i-1])) # Korekce hodnoty na bariéře
        y[i + 1] <- y[i] + sample(c(1, -1, -5), size = 1, prob = c(p, p1, p2)) # Generování dalšího kroku
      }
      
      # Generování dalšího kroku, pokud hodnota leží mezi bariérami
      else {
        y[i + 1] <- y[i] + sample(c(1, -1, -5), size = 1, prob = c(p, p1, p2))
      }
    }
    data <- data.frame(t = 0:a, y = y)
    return(data)
  }

simulace <- SimulateRandomWalkBarrier2(
  n = 100,
  p = 0.4,
  p1 = 0.4,
  p2 = 0.2,
  start = 7,
  bar1 = 0,
  bar2 = 10
)

simulace <- head(simulace, -1)

plot(simulace$t, simulace$y, type = "b")
```




