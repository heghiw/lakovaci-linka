proces<- function (t=c(0,1),mu=10,sigma=1,lambda=100){
  t.min<- min(t)
  t.max<-max(t)

time<- rep(0,1000)
time[1]<-t.min


for (i in 1:1000) {
  if (time[i] < t.max) {
    time[i+1]<- time[i] + rexp(n=1,rate=lambda)
  }
  else if (time[i]>=t.max) {
    time[i] = t.max
   a=i
   break
  }
}

time<-time[1:a]
n<-length(time)
Xt <- rep(0,n)
Xt[1] = 0

for (i in 1:(n-1)) {
 Xt[i+1]<-Xt[i] + rnorm(n=1,mean=mu,sd=sigma)  
}

results<- data.frame(time,Xt)
print(results) }

results<-proces(t=c(0,1),mu=10,sigma=1,lambda=100)

plot(results$time, results$Xt, type = "s")
