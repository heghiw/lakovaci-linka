
DrunkWalkMod <- function(s) {
  
  P <- diag(0.2,nrow=s,ncol=s) # inicializace, same nuly
  
  P[1, 1] <- 1 # prvni radek
  P[s, s] <- 1 # posledni radek 1 
  
  
  for (i in 2:(s - 1)) { # druhy az predposledni radek
    P[i, i - 1] <- 0.3 # doleva s p=0.3
    P[i, i + 1] <- 0.4 # doprava s p=0.4
    
    
  }
  P[3:s-1,1]<-0.1 # z libovolneho stavu do stavu 1 taxikem
  P[2, 1] <- 0.1+0.3 # ze stavu 2 na stav 1 je moznost se vratit bud´ taxikem s p=0.1 nebo doleva s p=0.3
  state.names <- paste0("S", 1:s) # spoji retezce "S" a cisla od 1 do 6
  rownames(P) <- state.names      # pojmenuje radky
  colnames(P) <- state.names      # pojmenuje sloupce
  
  return(P)
  
}


IsMatrixStochastic <- function(P) {
  sto <- (all(P >= 0) && all(abs(rowSums(P) - 1) < 1e-9))
  return(sto)
}


IsMatrixStochastic(DrunkWalkMod(6)) # matice je stochasticka 