



## Diskretni pravdepodobnostni funkce pro Norm

disknorm_prob = function (mn, smod, krok, desetiny = TRUE) {
  
  
  if ( smod != 0) {
    
    
    zaok = ifelse(desetiny == TRUE, nchar(krok) - 2, -nchar(krok) + 1)
    
    hranice_d = round(qnorm(0.001, mn, smod), zaok)
    
    hranice_h = round(qnorm(0.999, mn, smod), zaok)
    
    
    hodnoty = seq(hranice_d, hranice_h, by = krok)
    
    
    fx = dnorm(hodnoty, mn, smod)
    
    probab = fx/sum(fx)
    
    
  }
  
  if ( smod == 0) {
    
    hodnoty = c(mn - krok, mn, mn + krok)
    
    probab = c(0,1,0)
    
  }
  
  return(probab)
  
}


disknorm_prob(0,1, 0.1)

disknorm_prob(0,0,0.1)






Signaly_Markchain = function (krok, chaos) {
  
  
  s = length(seq(0,1, by = krok))
  
  markchain = matrix(NA, s, s)
  
  
  
  for (i in seq(0,1, by = krok)) {
    
    pravd = disknorm_prob(0, abs(1 - i - 0.5)*chaos, krok ) ## chaos
    
    
    if ( length(pravd)/2 < s ) {
      
      pravd = c(rep(0,s), pravd, c(rep(0,s)))
      
    } 
    
    
    maximum = which(pravd == max(pravd))
    
    dolni = maximum - which(i == seq(0,1, krok)) + 1
    
    horni = maximum + length(seq(0,1, by = krok)) - which(i == seq(0,1, krok))
    
    dolni_kumul = sum(pravd[1:dolni])
    
    horni_kumul = sum(pravd[horni:length(pravd)])
    
    markchain[which(i == seq(0,1, krok)),] = pravd[(dolni):(horni)]
    
    markchain[which(i == seq(0,1, krok)),1] = dolni_kumul
    
    markchain[which(i == seq(0,1, krok)),s] = horni_kumul
    
    
  } 
  
  return(markchain)
  
}


signal_mark = Signaly_Markchain(krok = 0.1, chaos = 1.3)


rowSums(signal_mark)

all(rowSums(signal_mark) == 1)

sum(signal_mark[5,])
sum(signal_mark[5,]) ==1






round(Signaly_Markchain(0.1,1.3),3)

round(Signaly_Markchain(0.1,20),3)

round(Signaly_Markchain(0.2,1.3),3)






