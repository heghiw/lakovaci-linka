library(expm)
ReachabilityMatrix <- function(P) {
  s <- nrow(P) 
  reach <- matrix(FALSE, nrow = s, ncol = s) 
  for (t in 0:s) { 
    reach <- reach | (P %^% t > 0) 
  }
  return(reach)
}


Iftrans4<-function(N)  {
  N<-ReachabilityMatrix(N) 
  s<-nrow(N)               #pocet stavu
  b<-0                     #definice promenne pro pocitani 
  for (i in 1:s) {
    for (j in 1:s) { if(N[i,j]==TRUE & N[j,i]==TRUE)  {
      
      b<-b+1   }           
      else {b<-b}
    } 
    if(b==sum( N[i,] ,na.rm=TRUE)) {           
      cat(i," Stav je rekurentni \n")
      
    } 
    else {
      cat( i,"Stav je tranzientni \n")
    }
    b<-0}}


C3<-matrix(c(0.0 ,0.0, 0.7, 0.0, 0.0 ,0.3, 0.0 ,0.0,
             0.0, 0.0, 0.3, 0.0, 0.0, 0.7, 0.0, 0.0,
             0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
             0.0, 0.0, 0.0, 0.2, 0.8, 0.0, 0.0, 0.0,
             0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0,
             0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,
             0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
             0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0
),nrow=8,ncol=8,byrow=TRUE)
Iftrans4(C3)
